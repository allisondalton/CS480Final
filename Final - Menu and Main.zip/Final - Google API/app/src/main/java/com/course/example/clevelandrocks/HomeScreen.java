/*
 * This is a demo of explicit and implicit intents.
 * The implicit intents call existing Android applications
 * Notice the permission in the Manifest file. We need this because
 * the app is placing a call, not just opening the dialer.
 * This is a dangerous permission so also needs a runtime permission in the
 * application's Settings.
 *
 * For privacy concerns, using the browser package, requires permission
 * in the Manifest using <queries>.
 */
package com.course.example.clevelandrocks;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class HomeScreen extends Activity implements OnClickListener {

    private ImageView img;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(android.R.style.Theme_Dialog);
        setContentView(R.layout.main2);
        
        Button newButton = (Button)findViewById(R.id.second_button);
        newButton.setOnClickListener(this);
        
        Button aboutButton = (Button)findViewById(R.id.third_button);
        aboutButton.setOnClickListener(this);
        
        Button newAppButton = (Button)findViewById(R.id.fourth_button);
        newAppButton.setOnClickListener(this);
        
        Button exitButton = (Button)findViewById(R.id.exit_button);
        exitButton.setOnClickListener(this);

        img = (ImageView) findViewById(R.id.simple_anim);
        //set ImageView background to AnimationDrawable XML resource.
        img.setBackgroundResource(R.drawable.simple_animation);

        //instantiate inner classes
        AnimationStart start = new AnimationStart();
        AnimationStop stop = new AnimationStop();

        Timer t = new Timer();
        t.schedule(start, 1000);
        
    }

    //avoids runtime check for permission to CALL_PHONE
    public void onClick(View v)  {
        switch (v.getId()) {
         //implicit intent, call GoogleMaps
        case R.id.second_button:

            Intent i1 = new Intent(HomeScreen.this, OptionsMenu.class);
            //i1.setComponent(new ComponentName("com.course.example.optionsmenu;",
                  //  "com.course.example.optionsmenu.OptionsMenu;"));
            startActivity(i1);
            break;

        //implicit intent, open dialer and make call
        case R.id.third_button:
            Intent i2 = new Intent();
            i2.setComponent(new ComponentName("com.course.example.clevelandrocks;",
                    "com.course.example.clevelandrocks.MapsActivity;"));
            startActivity(i2);
            break;

         //explicit intent for an Activity in another application
         //format is ComponentName(package, class)
         //be sure other app has been run at least once so that its package
         //is in the file system.
        case R.id.fourth_button:
        	//Intent i3 = new Intent();
        	//i3.setComponent(new ComponentName("com.course.example.widgets",
        	//		"com.course.example.widgets.Widgets"));
            //startActivity(i3);
           break;
           
        case R.id.exit_button:
           finish();
           break;
        }
     }
    class AnimationStart extends TimerTask {

        @Override
        public void run() {
            // Get the background, which has been compiled to an AnimationDrawable object.
            AnimationDrawable frameAnimation = (AnimationDrawable) img.getBackground();
            frameAnimation.start();
        }
    }

    class AnimationStop extends TimerTask {

        @Override
        public void run() {
            // Get the background, which has been compiled to an AnimationDrawable object.
            AnimationDrawable frameAnimation = (AnimationDrawable) img.getBackground();
            frameAnimation.stop();
        }
    }
     
    
}