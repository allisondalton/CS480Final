package com.example.assignment1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.KeyEvent;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Toast;


public class WebLookup extends Activity {
    private EditText url_edit;
    private Button go_button;
    private WebView web_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web_lookup);

        //get references to widgets
        url_edit = (EditText) findViewById(R.id.url_edit);
        go_button = (Button) findViewById(R.id.go_button);
        web_view = (WebView) findViewById(R.id.web_view);

        web_view.getSettings().setJavaScriptEnabled(true);

        //ensure clicking links keep opening in the widget rather than opening the browser
        web_view.setWebViewClient(new WebViewClient());
        web_view.loadUrl("https://usaultimate.org/rules/");

        // Set button to go to entered URL
        go_button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                web_view.loadUrl(url_edit.getText().toString());
            }
        });
        url_edit.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    url_edit.setText("https://usaultimate.org/rules/");
                    web_view.loadUrl(url_edit.getText().toString());
                    return true;
                }
                return false;
                    }
                }
        );
    }

    //the back key navigates back to the previous web page
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && web_view.canGoBack()) {
            web_view.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    //when the web lookout finishes
    protected void onStop() {
        super.onStop();
        Intent i1 = new Intent(this, MainActivity.class);
        startActivity(i1);
        Toast.makeText(this, "Web lookup finished.", Toast.LENGTH_LONG)
                .show();
    }
}

