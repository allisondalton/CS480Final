package com.course.example.clevelandrocks;

import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    //next two variables are part of a test for longPress event
    private long lastTouchTimeDown = -1;
    private long lastTouchTimeUp = -1;
    private static final float zoom = 10.0f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);

        //center map and set zoom level
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(42.3855, -71.2218), zoom));

        //set markers
        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(42.0582, -71.0808))
                .title("Stonehill College")
                .snippet("Sectionals")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));

        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(42.3855, -71.2218))
                .title("Bentley University")
                .snippet("Home tournament")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));

        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(42.2936, -71.3059))
                .title("Wellesley College")
                .snippet("First 'learn'ament")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));

        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(42.3657, -71.2586))
                .title("Brandeis University")
                .snippet("Scrimmage")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));

        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(42.4085, -71.1183))
                .title("Tufts University")
                .snippet("Regionals")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));

        //set listeners
        mMap.setOnMarkerClickListener(
                new GoogleMap.OnMarkerClickListener() {

                    public boolean onMarkerClick(Marker m) {
                        String title = m.getTitle();
                        String snip = m.getSnippet();
                        Toast.makeText(getApplicationContext(), title + "\n" + snip, Toast.LENGTH_LONG).show();
                        return true;
                    }
                }
        );

        //enable a zoom control
        mMap.getUiSettings().setZoomControlsEnabled(true);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_S) {
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            return (true);
        }
        else if (keyCode == KeyEvent.KEYCODE_N) {
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            return (true);
        }
        return (super.onKeyDown(keyCode, event));
    }


}

