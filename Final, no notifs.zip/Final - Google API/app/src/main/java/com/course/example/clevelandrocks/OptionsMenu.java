package com.course.example.clevelandrocks;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Locale;


public class OptionsMenu extends Activity implements AdapterView.OnItemClickListener, OnInitListener {

	private final String file = "list.txt";
	private TextView selection;
	private ListView list;
	int position1;
	private TextToSpeech speaker;
	private static final String tag = "Widgets";
	private OutputStreamWriter out;
	private String line;

	ArrayList<String> items = new ArrayList<String>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		//grab values from main.xml
		selection=(TextView)findViewById(R.id.selection);
		list = (ListView)findViewById(R.id.list);
		list.setOnItemClickListener(this);

		//Initialize Text to Speech engine (context, listener object)
		speaker = new TextToSpeech(this, this);

		ArrayAdapter<String> aa = new ArrayAdapter<>(
				this,
				R.layout.item,     //Android supplied List item format
				items);
		list.setAdapter(aa);    //connect ArrayAdapter to <ListView>

		try {
		//open stream for reading from file
		InputStream in = openFileInput(file);
		InputStreamReader isr = new InputStreamReader(in);
		BufferedReader reader = new BufferedReader(isr);
		String str = null;

		//close input stream
		reader.close();

		} catch (IOException e) {
			Log.e("IOTest", e.getMessage());
		}

		//open output stream for writing
		try {
			out = new OutputStreamWriter(openFileOutput(file, MODE_PRIVATE)); // also try MODE_APPEND
		} catch (IOException e) {}

	}

	//speak methods will send text to be spoken
	public void speak(String output){
		speaker.speak(output, TextToSpeech.QUEUE_FLUSH, null, "Id 0");
	}

	// Implements TextToSpeech.OnInitListener.
	public void onInit(int status) {
		// status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
		if (status == TextToSpeech.SUCCESS) {
			// Set preferred language to US english.
			// If a language is not be available, the result will indicate it.
			int result = speaker.setLanguage(Locale.US);

			if (result == TextToSpeech.LANG_MISSING_DATA ||
					result == TextToSpeech.LANG_NOT_SUPPORTED) {
				// Language data is missing or the language is not supported.
				Log.e(tag, "Language is not available.");
			} else {
				// The TTS engine has been successfully initialized
//				speak("Please enter your bill amount");
				Log.i(tag, "TTS Initialization successful.");
			}
		} else {
			// Initialization failed.
			Log.e(tag, "Could not initialize TextToSpeech.");
		}
	}

	// on destroy
	public void onDestroy(){

		// shut down TTS engine
		if(speaker != null){
			speaker.stop();
			speaker.shutdown();
		}
		super.onDestroy();
	}

	//options menu
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	//context menu
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
									ContextMenu.ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		getMenuInflater().inflate(R.menu.menu2, menu);
	}

	//set edittext to to-do entry without number
	//save position of listview for later
	public void onItemClick(AdapterView<?> parent, View v, int position, long id) {

    	String test = items.get(position);
    	test = test.substring(3);
		selection.setText(test);
		position1 = position;

	}

    @Override
	public boolean onOptionsItemSelected(MenuItem item) {

		ArrayAdapter<String> aa = new ArrayAdapter<>(
				this,
				R.layout.item,     //Android supplied List item format
				items);
		list.setAdapter(aa);    //connect ArrayAdapter to <ListView>

		int itemID = item.getItemId();  //get id of menu item picked

			switch (itemID) {

			//add button
		    case R.id.add :
				String selectionString = selection.getText().toString();

				//use size for number
				int num = items.size();
				items.add(num+1 + ". " + selectionString);
				aa.notifyDataSetChanged();

				//clear edittext
				selection.setText("");

				// if speaker is talking, stop it
				if(speaker.isSpeaking()){
					Log.i(tag, "Speaker Speaking");
					speaker.stop();
					// else start speech
				} else {
					Log.i(tag, "Speaker Not Already Speaking");
					speak(selectionString);
				}

				return true;

		    //update button
		    case R.id.update :

		    	//get number from list entry that was clicked
		    	String s = items.get(position1);
		    	char j = s.charAt(0);

		    	//update entry with same number
				String selectionString1 = selection.getText().toString();
		    	items.set(position1, j + ". " + selectionString1);
				aa.notifyDataSetChanged();

				//clear edittext
				selection.setText("");

		    	return true;

		    //save button
			case R.id.save:

				try {
					for (int i = 0; i < items.size(); i++) {

						//receive number of items in arraylist
						String s2 = items.get(i);
						line = s2.trim();

						if (!line.equals("")) { // empty string ends loop
							out.write(line + " \n");
						}
					};

					//clear listview
					items.clear();
					aa.notifyDataSetChanged();

					//close output stream
					out.close();

				} catch (IOException e) {
					Log.e("IOTest", e.getMessage());
				}

				return true;

			//close button
			case R.id.close:
					finish();
					return true;

		    default: super.onOptionsItemSelected(item);
		    }


		   		   
	    return false;
	}


}