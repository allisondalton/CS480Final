//Juliana Spitzner - Assignment 1
//February 25, 2022

package com.course.example.clevelandrocks;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends Activity {

    public Button web, dial, map, goal1, assist1, defense1, buttonTimer, visitorGoalButton;
    private Button goal2, assist2, defense2, goal3, assist3, defense3, goal4, assist4, defense4;
    private TextView textGoal, textScore, textAssist, textDefense, timer, textScoreV;
    private TextView textGoal2, textScore2, textAssist2, textDefense2;
    private TextView textGoal3, textScore3, textAssist3, textDefense3;
    private TextView textGoal4, textScore4, textAssist4, textDefense4;
    private EditText check;
    private int goalCount = 0;
    private int assistCount = 0;
    private int defenseCount = 0;
    private int goalCount2 = 0;
    private int assistCount2 = 0;
    private int defenseCount2 = 0;
    private int goalCount3 = 0;
    private int assistCount3 = 0;
    private int defenseCount3 = 0;
    private int goalCount4 = 0;
    private int assistCount4 = 0;
    private int defenseCount4 = 0;
    private int scoreCount = 0;
    private int scoreCountV = 0;
    public int counter = 7200000;
    private static final DecimalFormat df = new DecimalFormat("0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        web = (Button)findViewById(R.id.webRulebook);
        dial = (Button)findViewById(R.id.dialTrainer);
        map = (Button)findViewById(R.id.map);
        buttonTimer = (Button) findViewById(R.id.buttonTimer);
        visitorGoalButton = (Button) findViewById(R.id.visitorGoalButton);
        goal1 = (Button)findViewById(R.id.goal1);
        assist1 = (Button)findViewById(R.id.assist1);
        defense1 = (Button)findViewById(R.id.defense1);
        goal2 = (Button)findViewById(R.id.goal2);
        assist2 = (Button)findViewById(R.id.assist2);
        defense2 = (Button)findViewById(R.id.defense2);
        goal3 = (Button)findViewById(R.id.goal3);
        assist3 = (Button)findViewById(R.id.assist3);
        defense3 = (Button)findViewById(R.id.defense3);
        goal4 = (Button)findViewById(R.id.goal4);
        assist4 = (Button)findViewById(R.id.assist4);
        defense4 = (Button)findViewById(R.id.defense4);

        timer = (TextView) findViewById(R.id.timer);
        textScoreV = (TextView) findViewById(R.id.textScoreV);
        textScore = (TextView)findViewById(R.id.textScore);
        textGoal = (TextView)findViewById(R.id.textGoal);
        textAssist = (TextView)findViewById(R.id.textAssist);
        textDefense = (TextView)findViewById(R.id.textDefense);
        textGoal2 = (TextView)findViewById(R.id.textGoal2);
        textAssist2 = (TextView)findViewById(R.id.textAssist2);
        textDefense2 = (TextView)findViewById(R.id.textDefense2);
        textGoal3 = (TextView)findViewById(R.id.textGoal3);
        textAssist3 = (TextView)findViewById(R.id.textAssist3);
        textDefense3 = (TextView)findViewById(R.id.textDefense3);
        textGoal4 = (TextView)findViewById(R.id.textGoal4);
        textAssist4 = (TextView)findViewById(R.id.textAssist4);
        textDefense4 = (TextView)findViewById(R.id.textDefense4);

        textScore.setText(Integer.toString(scoreCount));
        textGoal.setText(Integer.toString(goalCount));
        textAssist.setText(Integer.toString(assistCount));
        textDefense.setText(Integer.toString(defenseCount));
        textGoal2.setText(Integer.toString(goalCount2));
        textAssist2.setText(Integer.toString(assistCount2));
        textDefense2.setText(Integer.toString(defenseCount2));
        textGoal3.setText(Integer.toString(goalCount3));
        textAssist3.setText(Integer.toString(assistCount3));
        textDefense3.setText(Integer.toString(defenseCount3));
        textGoal4.setText(Integer.toString(goalCount4));
        textAssist4.setText(Integer.toString(assistCount4));
        textDefense4.setText(Integer.toString(defenseCount4));


        buttonTimer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                new CountDownTimer(counter, 1000){
                    public void onTick(long millisUntilFinished){
                        timer.setText((millisUntilFinished / 60000)+":"+(millisUntilFinished % 60000 / 1000));
                        counter--;
                    }
                    public  void onFinish(){
                        timer.setText("Game over!");
                    }
                }.start();
            }
        });

        //set listener of web button
        web.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                Intent i1 = new Intent(v.getContext(), com.course.example.clevelandrocks.WebLookup.class);
                startActivity(i1);

                if (i1.resolveActivity(getPackageManager()) != null) {
                    startActivity(i1);
                }
                Intent i4 = new Intent();
                i4.setComponent(new ComponentName("com.course.example.clevelandrocks",
                        "com.course.example.clevelandrocks.WebLookup"));
                startActivity(i4);
            }
        });

        visitorGoalButton.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                scoreCountV += 1;
                textScoreV.setText(Integer.toString(scoreCountV));
            }
        });

        //set listener of goal button
        goal1.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                goalCount += 1;
                scoreCount += 1;
                textGoal.setText(Integer.toString(goalCount));
                textScore.setText(Integer.toString(scoreCount));
            }
        });

        goal2.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                goalCount2 += 1;
                scoreCount += 1;
                textGoal2.setText(Integer.toString(goalCount2));
                textScore.setText(Integer.toString(scoreCount));
            }
        });

        goal3.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                goalCount3 += 1;
                scoreCount += 1;
                textGoal3.setText(Integer.toString(goalCount3));
                textScore.setText(Integer.toString(scoreCount));
            }
        });

        goal4.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                goalCount4 += 1;
                scoreCount += 1;
                textGoal4.setText(Integer.toString(goalCount4));
                textScore.setText(Integer.toString(scoreCount));
            }
        });

        //set listener of assist button
        assist1.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                assistCount += 1;
                textAssist.setText(Integer.toString(assistCount));
            }
        });
        assist2.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                assistCount2 += 1;
                textAssist2.setText(Integer.toString(assistCount2));
            }
        });
        assist3.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                assistCount3 += 1;
                textAssist3.setText(Integer.toString(assistCount3));
            }
        });
        assist4.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                assistCount4 += 1;
                textAssist4.setText(Integer.toString(assistCount4));
            }
        });
        //set listener of defense button
        defense1.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                defenseCount += 1;
                textDefense.setText(Integer.toString(defenseCount));
            }
        });
        defense2.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                defenseCount2 += 1;
                textDefense2.setText(Integer.toString(defenseCount2));
            }
        });
        defense3.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                defenseCount3 += 1;
                textDefense3.setText(Integer.toString(defenseCount3));
            }
        });
        defense4.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                defenseCount4 += 1;
                textDefense4.setText(Integer.toString(defenseCount4));
            }
        });

        //set listener of dial button
        dial.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                Uri uri3 = Uri.parse("tel:9083002295");
                Intent i3 = new Intent(Intent.ACTION_DIAL,uri3);
                if (i3.resolveActivity(getPackageManager()) != null) {
                    startActivity(i3);
                }
            }
        });

        //set listener of map button
        map.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                Uri uri2 = Uri.parse("geo:42.3889167,-71.2208033?z=18");
                Intent i2 = new Intent(Intent.ACTION_VIEW,uri2);
                //check if GoogleMaps project is on the platform
                if (i2.resolveActivity(getPackageManager()) != null) {
                    startActivity(i2);
                }
            }
        });



    }
}